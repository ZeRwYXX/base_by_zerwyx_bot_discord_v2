const Discord = require('discord.js');
const { MessageEmbed} = require('discord.js');



module.exports.run = async(bot, message, args) => {
    const user = message.mentions.users.first() || message.author;
    if (!config.owner.includes(message.author.id)) return message.author.send('Vous ne pouvez pas utilisé cette commande car vous êtes pas owner ;)')
    
    const avatar = new MessageEmbed()
    .setColor('#ff0000')
    .setAuthor(user.username)
//avatar user mention
    .setImage(user.avatarURL({ format: 'png', dynamic: true, size: 1024}));
    message.channel.send(avatar)
    console.log('Un owner a effectué la commande "avatar"')
}

module.exports.help = {
    name: "av"
}